﻿// See https://aka.ms/new-console-template for more information
using System;
using Dapper;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data;
using Microsoft.Data.SqlClient;
using System.Linq;
using System.Numerics;
using HelloWorld.Data;

namespace HelloWorld
{
    public class Computer
    {
        // private string _motherBoard;
        // private string MotherBoard{get{return _motherBoard;} set{_motherBoard=value;}}
        public string MotherBoard { get; set; }
        public int CPUCores { get; set; }
        public bool HasWiFi { get; set; }
        public bool HasLTE { get; set; }
        public DateTime ReleaseDate { get; set; }
        public Decimal Price { get; set; }
        public string VideoCard { get; set; }


       public Computer()
        {
            if(VideoCard==null)
            {
                VideoCard="";
            }
            if(MotherBoard==null)
            {
                MotherBoard="";
            }
        }
    }
    internal class Program
    {
        
        static void Main(string[] args)
        {
            DataContextDapper dapper=new DataContextDapper();

            string sqlCommand="SELECT GETDATE()";
            DateTime rightNow= dapper.LoadDataSingle<DateTime>(sqlCommand);

            Computer myComputer=new Computer()
            {
                MotherBoard="Z695",
                HasWiFi=true,
                HasLTE=false,
                ReleaseDate=DateTime.Now,
                Price=423.56m,
                VideoCard="RTC2025"
            };
            string sql=@"INSERT INTO TutorialAppSchema.Computer (
                MotherBoard,
                HasWiFi,
                HasLTE,
                ReleaseDate,
                Price,
                VideoCard
            ) VALUES('" + myComputer.MotherBoard 
            +"','"+myComputer.HasWiFi
            +"','"+myComputer.HasLTE
            +"','"+myComputer.ReleaseDate
            +"','"+myComputer.Price
            +"','"+myComputer.VideoCard
            +"')";

            
            //int result= dapper.ExecuteSqlWithRowCount(sql);
            bool result = dapper.ExecuteSql(sql);

            //    Console.WriteLine(result);

            string sqlSelect=@"SELECT 
                Computer.MotherBoard,
                Computer.HasWiFi,
                Computer.HasLTE,
                ReleaseDate,
                Computer.Price,
                Computer.VideoCard
             FROM TutorialAppSchema.Computer";
            // List<Computer> computers=dbConnection.Query<Computer>(sqlSelect).ToList();
             IEnumerable<Computer> computers=dapper.LoadData<Computer>(sqlSelect);
             Console.WriteLine("'MotherBoard','HasWiFi','HasLTE','ReleaseDate','Price','VideoCard'");
             foreach(Computer singleComputer in computers)
             {
                Console.WriteLine(
                    "'" + singleComputer.MotherBoard 
            +"','"+ singleComputer.HasWiFi
            +"','"+ singleComputer.HasLTE
            +"','"+ singleComputer.ReleaseDate
            +"','"+ singleComputer.Price
            +"','"+ singleComputer.VideoCard
                );
             }
            Console.ReadLine();
        }
    }
} 